<?php

require_once 'inc/custom-header.php';

add_action('customize_register',

    function($customizer){

        // Settings
        $customizer->add_section(
            'section_settings',
            array(
                'title' => 'Settings',
                'priority' => 1
            )
        );
        $customizer->add_setting(
            'domainPrice',
            array('default' => '$1')
        );
        $customizer->add_control(
            'domainPrice',
            array(
                'label' => 'Domain Price:',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'purchaseUrl',
            array('default' => 'http://paypal.com')
        );
        $customizer->add_control(
            'purchaseUrl',
            array(
                'label' => 'Purchase Url:',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'securityNotice',
            array('default' => '100% secure payment by PayPal')
        );
        $customizer->add_control(
            'securityNotice',
            array(
                'label' => 'Security Notice:',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'bidButtonText',
            array('default' => '$1')
        );
        $customizer->add_control(
            'bidButtonText',
            array(
                'label' => 'Bid Button Text:',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'bidButtonUrl',
            array('default' => 'http://flippa.com/')
        );
        $customizer->add_control(
            'bidButtonUrl',
            array(
                'label' => 'Bid Button URL:',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'contactFormShortcode',
            array('default' => '')
        );
        $customizer->add_control(
            'contactFormShortcode',
            array(
                'label' => 'Contact Form Shortcode',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'contactUsIcon',
            array('default' => 'fa-phone')
        );
        $customizer->add_control(
            'contactUsIcon',
            array(
                'label' => 'FontAwesome Icon Class:',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'contactPhone',
            array('default' => '1-800-')
        );
        $customizer->add_control(
            'contactPhone',
            array(
                'label' => 'Contact Us:',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'footerAnchorText',
            array('default' => 'GetPremiumDomains')
        );
        $customizer->add_control(
            'footerAnchorText',
            array(
                'label' => 'Anchor text:',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'footerUrl',
            array('default' => 'http://example.com')
        );
        $customizer->add_control(
            'footerUrl',
            array(
                'label' => 'Footer URL:',
                'section' => 'section_settings',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'removeCopyright',
            array(
                'type' => 'option',
            )
        );
        $customizer->add_control(
            'removeCopyright',
                array(
                'label'    => 'Remove "Developed with..."',
                'section'  => 'section_settings',
                'settings' => 'removeCopyright',                
                'type'     => 'checkbox',
            )
        );

        // Feature One
        $customizer->add_section(
            'section_feature_one',
            array(
                'title' => 'Feature #1',
                'priority' => 2
            )
        );
        $customizer->add_setting(
            'featureOneIcon',
            array('default' => 'fa-tree')
        );
        $customizer->add_control(
            'featureOneIcon',
            array(
                'label' => 'FontAwesome Icon Class:',
                'section' => 'section_feature_one',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'featureOneTitle',
            array('default' => 'Domain Age')

        );
        $customizer->add_control(
            'featureOneTitle',
            array(
                'label' => 'Feature Name:',
                'section' => 'section_feature_one',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'featureOneValue',
            array('default' => '10 Years')
        );
        $customizer->add_control(
            'featureOneValue',
            array(
                'label' => 'Feature Value:',
                'section' => 'section_feature_one',
                'type' => 'text'
            )
        );

        // Feature Two
        $customizer->add_section(
            'section_feature_two',
            array(
                'title' => 'Feature #2',
                'priority' => 3
            )
        );
        $customizer->add_setting(
            'featureTwoIcon',
            array('default' => 'fa-users')
        );
        $customizer->add_control(
            'featureTwoIcon',
            array(
                'label' => 'FontAwesome Icon Class:',
                'section' => 'section_feature_two',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'featureTwoTitle',
            array('default' => 'Monthly Visits')
        );
        $customizer->add_control(
            'featureTwoTitle',
            array(
                'label' => 'Feature Name:',
                'section' => 'section_feature_two',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'featureTwoValue',
            array('default' => '5.000')
        );
        $customizer->add_control(
            'featureTwoValue',
            array(
                'label' => 'Feature Value:',
                'section' => 'section_feature_two',
                'type' => 'text'
            )
        );

        // Feature Three
        $customizer->add_section(
            'section_feature_three',
            array(
                'title' => 'Feature #3',
                'priority' => 4
            )
        );
        $customizer->add_setting(
            'featureThreeIcon',
            array('default' => 'fa-diamond')
        );
        $customizer->add_control(
            'featureThreeIcon',
            array(
                'label' => 'FontAwesome Icon Class:',
                'section' => 'section_feature_three',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'featureThreeTitle',
            array('default' => 'Monthly Revenue')
        );
        $customizer->add_control(
            'featureThreeTitle',
            array(
                'label' => 'Feature Name:',
                'section' => 'section_feature_three',
                'type' => 'text'
            )
        );
        $customizer->add_setting(
            'featureThreeValue',
            array('default' => '$100.00')
        );
        $customizer->add_control(
            'featureThreeValue',
            array(
                'label' => 'Feature Value:',
                'section' => 'section_feature_three',
                'type' => 'text'
            )
        );
        
        // Colors
        $customizer->add_section(
            'section_colors',
            array(
                'title' => 'Background & Colors',
                'priority' => 5
            )
        );
        $customizer->add_setting(
            'bckgImage',
            array(
                'default'		=> '',
                'sanitize_callback'	=> 'esc_url_raw',
                'transport'		=> 'postMessage'
            )
        );
        $customizer->add_control(
            new WP_Customize_Image_Control(
                $customizer,
                'bckgImage',
                array(
                    'label'			=> __( 'Background Image', 'wpdomainpro' ),
                    'section'		=> 'section_colors',
                    'settings'		=> 'bckgImage',
                )
            )
        );
        $customizer->add_setting(
            'bckgColor',
            array('default' => '#ffffff')
        );
        $customizer->add_control( 
            new WP_Customize_Color_Control( 
            $customizer, 
            'bckgColor', 
            array(
                'label'      => __( 'Background Color', 'wpdomainpro' ),
                'section'    => 'section_colors',
                'settings'   => 'bckgColor',
            ) ) 
        );
        $customizer->add_setting(
            'skinColor',
            array('default' => '#0079c2')
        );
        $customizer->add_control( 
            new WP_Customize_Color_Control( 
            $customizer, 
            'skinColor', 
            array(
                'label'      => __( 'Skin Color', 'wpdomainpro' ),
                'section'    => 'section_colors',
                'settings'   => 'skinColor',
            ) ) 
        );
        $customizer->add_setting(
            'buttonHoverColor',
            array('default' => '#0769a5')
        );
        $customizer->add_control( 
            new WP_Customize_Color_Control( 
            $customizer, 
            'buttonHoverColor', 
            array(
                'label'      => __( 'Button Hover Color', 'wpdomainpro' ),
                'section'    => 'section_colors',
                'settings'   => 'buttonHoverColor',
            ) ) 
        );
        $customizer->add_setting(
            'buttonTextColor',
            array('default' => '#ffffff')
        );
        $customizer->add_control( 
            new WP_Customize_Color_Control( 
            $customizer, 
            'buttonTextColor', 
            array(
                'label'      => __( 'Button Text Color', 'wpdomainpro' ),
                'section'    => 'section_colors',
                'settings'   => 'buttonTextColor',
            ) ) 
        );
        $customizer->add_setting(
            'otherTextColor',
            array('default' => '#1d3b3d')
        );
        $customizer->add_control( 
            new WP_Customize_Color_Control( 
            $customizer, 
            'otherTextColor', 
            array(
                'label'      => __( 'Other Text Color', 'wpdomainpro' ),
                'section'    => 'section_colors',
                'settings'   => 'otherTextColor',
            ) ) 
        );
        $customizer->add_setting(
            'featuresBckgColor',
            array('default' => '#e4e8eb')
        );
        $customizer->add_control( 
            new WP_Customize_Color_Control( 
            $customizer, 
            'featuresBckgColor', 
            array(
                'label'      => __( 'Features Background Color', 'wpdomainpro' ),
                'section'    => 'section_colors',
                'settings'   => 'featuresBckgColor',
            ) ) 
        );
    }
);

function customizer_live_preview() {
	wp_enqueue_script(
		'theme-customizer',
		get_template_directory_uri() . '/js/theme-customizer.js',
		array( 'customize-preview' ),
		'0.1.0',
		true
	);
}
add_action( 'customize_preview_init', 'customizer_live_preview' );


function theme_setup_options () {
    update_option('contactPhone', '1-800-');
    update_option('bidButtonUrl', 'http://flippa.com');
}
add_action('after_switch_theme', 'theme_setup_options');
