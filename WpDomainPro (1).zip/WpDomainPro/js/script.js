$=jQuery.noConflict();

$(document).ready(function(){

    MicroModal.init();
    console.log('DOM ready');

    $('#js--offer-submit-modal').on('click', function (event) {
        MicroModal.show('offer-submit-modal');
        event.preventDefault();
    });

});