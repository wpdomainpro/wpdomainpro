(function( $ ) {
	"use strict";
	wp.customize( 'bckgImage', function( value ) {
		value.bind( function( to ) {
			$( 'main.page__main' ).css( 'background-image', 'url( ' + to + ')' );
		} );
	});


})( jQuery );