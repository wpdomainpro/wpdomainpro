<?php

// ---------------------------------------------------------------------------------------------------------------------
// HEAD CLEANUP
// ---------------------------------------------------------------------------------------------------------------------

    // Emoji
    add_filter('emoji_svg_url', '__return_false' );
    remove_action('wp_head', 'print_emoji_detection_script', 7 );
    remove_action('wp_print_styles', 'print_emoji_styles' );

    // api.w.org
    function remove_unwanted_header_tags () {
        remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
        remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
    }
    add_action( 'after_setup_theme', 'remove_unwanted_header_tags' );

    // wp-embed.js
    function remove_unwanted_footer_scripts(){
        wp_deregister_script( 'wp-embed' );
    }
    add_action( 'wp_footer', 'remove_unwanted_footer_scripts' );

// ---------------------------------------------------------------------------------------------------------------------



// ---------------------------------------------------------------------------------------------------------------------
// HEAD STYLES
// ---------------------------------------------------------------------------------------------------------------------

    function theme_enqueue_styles() {
        wp_enqueue_style('micromodal-styles', get_template_directory_uri().'/css/vendor/modal.css', array(), null, 'screen');
        wp_enqueue_style('theme-styles', get_template_directory_uri().'/css/main.css', array(), null, 'screen');

        $custom_css = "";
        $bckgImage = get_theme_mod('bckgImage');
        if (!empty($bckgImage)) {
            $custom_css .= "main.page__main{background-image: url( $bckgImage )}";
        };
        $bckgColor = get_theme_mod('bckgColor');
        if (!empty($bckgColor)) {
            $custom_css .= "main.page__main{background-color: $bckgColor}";
        };
        $skinColor = get_theme_mod('skinColor');
        if (!empty($skinColor) && $skinColor != '#0079c2') {
            $custom_css .= "em,.features__icon,.cta__link,.chop-top a,.modal__title{color: $skinColor!important;}.button,.form__button{background-color: $skinColor!important;}.form__input:focus{border-color: $skinColor!important;}";
        };
        $buttonHoverColor = get_theme_mod('buttonHoverColor');
        if (!empty($buttonHoverColor)/* && $buttonHoverColor != '#0769a5'*/) {
            $custom_css .= ".button:hover,.form__button:hover{background-color: $buttonHoverColor!important;}.chop-top a:hover,a.cta__link:hover{color: $buttonHoverColor!important;}.form__input:focus{color: $buttonHoverColor!important;}";
        }
        $buttonTextColor = get_theme_mod('buttonTextColor');
        if (!empty($buttonTextColor) && $buttonTextColor != '#ffffff') {
            $custom_css .= ".button,.button:hover,.form__button,.form__button:hover{color: $buttonTextColor!important;}";
        };
        $otherTextColor = get_theme_mod('otherTextColor');
        if (!empty($otherTextColor) && $otherTextColor != '#1d3b3d') {
            $custom_css .= "html,body,.form__input{color: $otherTextColor!important;}";
        };
        $featuresBckgColor = get_theme_mod('featuresBckgColor');
        if (!empty($featuresBckgColor) && $featuresBckgColor != '#e4e8eb') {
            $custom_css .= ".page__fold--subtleBlue{background-color: $featuresBckgColor!important;}";/*.form__input{border: 1px solid $featuresBckgColor!important;}*/
        };
        echo '<style type="text/css">' . $custom_css . '</style>';
        
        wp_enqueue_style('fontawesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array(), null, 'all');
    }
    add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );

// ---------------------------------------------------------------------------------------------------------------------



function theme_slug_setup() {
    add_theme_support( 'title-tag' );
}
add_action( 'after_setup_theme', 'theme_slug_setup' );



// ---------------------------------------------------------------------------------------------------------------------
// HEAD SCRIPTS
// ---------------------------------------------------------------------------------------------------------------------

function add_theme_scripts(){
        wp_register_script( 'micromodal-script', get_template_directory_uri().'/js/vendor/micromodal.min.js', array('jquery'), null, false);
        wp_enqueue_script( 'micromodal-script' );
        wp_register_script( 'nameseller-script', get_template_directory_uri().'/js/script.js', array('jquery'), null, false);
        wp_enqueue_script( 'nameseller-script' );
    }

    add_action( 'wp_enqueue_scripts', 'add_theme_scripts' );

// ---------------------------------------------------------------------------------------------------------------------