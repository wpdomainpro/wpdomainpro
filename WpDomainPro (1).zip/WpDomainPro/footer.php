<?php wp_footer(); ?>
</div>


<div class="modal micromodal-slide" id="offer-submit-modal" aria-hidden="true">
    <div class="modal__overlay" tabindex="-1" data-micromodal-close>
        <div class="modal__container" role="dialog" aria-modal="true" aria-labelledby="offer-submit-modal-title">
            <header class="modal__header">
                <h2 class="modal__title">Send Us An Offer</h2>
                <button class="modal__close" aria-label="Close Modal" data-micromodal-close></button>
            </header>
            <div class="modal__content" id="offer-submit-modal-content">
                <?php
                    if (get_theme_mod('contactFormShortcode')!=''){
                        echo do_shortcode(get_theme_mod('contactFormShortcode'));
                    } else {
                        echo 'Please set up your contact form';
                    }
                ?>
            </div>
        </div>
    </div>
</div>

</body>
</html>