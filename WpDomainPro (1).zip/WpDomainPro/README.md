#INSTALL

- Install and activate __WP Head Cleanup__ WordPress plugin (make your HTML cleaner);
- Install and activate __Contact Form 7__ WordPress plugin;
- Create a new form in editor and add the following text inside:


    <p>[text* your-bid class:form__input placeholder "Your bid"]</p>
    <p>[email* your-email class:form__input placeholder "Your e-mail"]</p>
    <p>[text* your-name class:form__input placeholder "Your name"]</p>
    <p class="chop-bottom">[submit class:form__button "SEND YOUR OFFER"]</p>
    
- Enter form's shortcode into __Contact Form Shortcode__ input on Theme's customize page;
- Edit other customization settings;
- Have fun.