<?php
get_header(); ?>

<main class="page__main">
    <h1 class="visually-hidden">The domain is for sale!</h1>
    <section class="page__fold">
        <div class="page__bounds">
            <div class="grid">
                <div class="grid__cell grid__cell--center">
                    <h1>This domain is <em>for sale</em></h1>
                    <p class="chop-bottom">
                        <a href="<?php echo get_theme_mod('purchaseUrl')!=''?get_theme_mod('purchaseUrl'):'https://paypal.com/'; ?>" target="_blank" class="button button--primary">
                            <i class="fa fa-fw fa-shopping-cart"></i>
                            Buy Now for Just <?php echo get_theme_mod('domainPrice')!=''?get_theme_mod('domainPrice'):'$1'; ?>
                        </a>
                    </p>
                    <p class="chop-top"><small><?php echo get_theme_mod('securityNotice')!=''?get_theme_mod('securityNotice'):'100% secure payment by PayPal'; ?></small></p>
                </div>
            </div>
        </div>
    </section>
    <section class="page__fold page__fold--subtleBlue features">
        <div class="page__bounds page__bounds--narrow">
            <div class="grid">
                <div class="grid__cell grid__cell--center">
                    <h1 class="features__title">Features</h1>
                </div>
            </div>
            <div class="grid">
                <div class="grid__cell grid__cell--center features__feature">
                    <div class="features__icon">
                        <i class="fa fa-fw <?php echo get_theme_mod('featureOneIcon')!=''?get_theme_mod('featureOneIcon'):'fa-tree'; ?>"></i>
                    </div>
                    <div class="features__featureName">
                        <?php echo get_theme_mod('featureOneTitle')!=''?get_theme_mod('featureOneTitle'):'Domain Age'; ?>
                    </div>
                    <div class="features__featureValue">
                        <?php echo get_theme_mod('featureOneValue')!=''?get_theme_mod('featureOneValue'):'10 Years'; ?>
                    </div>
                </div>
                <div class="grid__cell grid__cell--center features__feature">
                    <div class="features__icon">
                        <i class="fa fa-fw <?php echo get_theme_mod('featureTwoIcon')!=''?get_theme_mod('featureTwoIcon'):'fa-users'; ?>"></i>
                    </div>
                    <div class="features__featureName">
                        <?php echo get_theme_mod('featureTwoTitle')!=''?get_theme_mod('featureTwoTitle'):'Monthly Visitors'; ?>
                    </div>
                    <div class="features__featureValue">
                        <?php echo get_theme_mod('featureTwoValue')!=''?get_theme_mod('featureTwoValue'):'5.000'; ?>
                    </div>
                </div>
                <div class="grid__cell grid__cell--center features__feature">
                    <div class="features__icon">
                        <i class="fa fa-fw <?php echo get_theme_mod('featureThreeIcon')!=''?get_theme_mod('featureThreeIcon'):'fa-diamond'; ?>"></i>
                    </div>
                    <div class="features__featureName">
                        <?php echo get_theme_mod('featureThreeTitle')!=''?get_theme_mod('featureThreeTitle'):'Monthly Revenue'; ?>

                    </div>
                    <div class="features__featureValue">
                        <?php echo get_theme_mod('featureThreeValue')!=''?get_theme_mod('featureThreeValue'):'$50.00'; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="page__fold actions">
        <div class="page__bounds">
            <div class="grid">
            <?php $bidButtonUrl = get_theme_mod('bidButtonUrl');
                if ($bidButtonUrl != ''): ?>
                <div class="actions__column actions__column--left">
                    <a class="button" target="_blank" href="<?php echo $bidButtonUrl;//'http://flippa.com' ?>" title="Make Your Bid">
                        <i class="fa fa-fw fa-gavel"></i>
                        <?php echo get_theme_mod('bidButtonText')!=''?get_theme_mod('bidButtonText'):'Bid On Flippa'; ?>
                    </a>
                </div>
                <div class="actions__column actions__column--middle"><strong>or</strong></div>
                <div class="actions__column actions__column--right">
                    <button class="button" id="js--offer-submit-modal">
                        <i class="fa fa-fw fa-paper-plane-o"></i>
                        Send Us An Offer
                    </button>
                </div>
            <?php else: ?>
                <div class="grid__cell grid__cell--center">
                    <button class="button" id="js--offer-submit-modal">
                        <i class="fa fa-fw fa-paper-plane-o"></i>
                        Send Us An Offer
                    </button>
                </div>
            <?php endif; ?>
            </div>
            <?php
            $contactPhone = get_theme_mod('contactPhone');
            if ($contactPhone != ''): ?>
            <div class="grid">
                <div class="grid__cell grid__cell--center">
                    <p class="cta">
                        <i class="fa fa-fw <?php echo get_theme_mod('contactUsIcon')!=''?get_theme_mod('contactUsIcon'):'fa-phone'; ?>"></i>
                        <strong><em>Contact Us</em> Now</strong>
                        <br>
                        <a class="cta__link" href="tel:<?php echo $contactPhone; ?>">
                            <?php echo $contactPhone;//'1-800-' ?>
                        </a>
                    </p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <footer class="page__fold page__footer">
        <div class="page__bounds">
            <div class="grid">
                <div class="grid__cell grid__cell--center">
                    <p class="chop-top">
                        <small>©<?php echo date("Y"); ?>
                            <a href="<?php echo get_theme_mod('footerUrl')!=''?get_theme_mod('footerUrl'):'example.net'; ?>" target="_blank">
                                <?php echo get_theme_mod('footerAnchorText')!=''?get_theme_mod('footerAnchorText'):'GetPremiumDomains'; ?>
                            </a>. All Rights Reserved.
                        <?php if (get_option('removeCopyright')!=1): ?><br>Developed with <i class="fa fa-fw fa-heart"></i> in <a href="http://wpdomain.pro" target="_blank">WPdomain.pro</a></small><?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </footer>
</main>

<?php get_footer(); ?>
